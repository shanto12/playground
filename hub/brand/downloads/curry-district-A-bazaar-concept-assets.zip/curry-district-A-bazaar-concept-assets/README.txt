CONCEPT ASSETS — USAGE RIGHTS TRANSFER ON AGREEMENT
===================================================

Curry District · Brand Glow-Up — Direction A · Bazaar
Prepared 05 Oct 2026 as part of an independent design proposal.
This is NOT the official Curry District identity. The files are concept artwork for review only.
Usage rights (logo, patterns, icons, illustrations) transfer to the restaurant only on a signed
agreement with the designer. Please don't print, publish or hand these to a vendor before then.

WHAT'S INSIDE
logo/svg ........ every lockup (stacked = primary, horizontal, text-only, tagline, emblem, stamp, favicon, app icons, avatars)
logo/svg/colourways  full-colour · reversed · mono-indigo · mono-cream · mono-saffron
logo/png ........ transparent PNG exports (1024–2000 px), favicons and app icons
patterns/svg .... 8 seamless repeats × 3 colourways (sunset · night · fresh). Vector: scale freely.
icons/svg ....... 43 colour icons (64×64). icons/svg-mono = single colour (currentColor). icons/sprite.svg = all symbols.
illustrations ... 12 dish illustrations: svg (master) + png 800×800 on cream and on saffron.

LOGO RULES (short version)
- Clear space: X = cap height of "CURRY". Keep 1X clear on every side (emblem alone: X = 1/4 of its width).
- Minimum size: stacked 120 px / 30 mm wide · horizontal 160 px / 40 mm · emblem 64 px / 15 mm · small emblem 24 px.
- Cream/white grounds: full-colour. Indigo grounds: reversed or mono-cream. Saffron: mono-indigo or mono-cream. Rani: mono-cream.
- Don't recolour, stretch, rotate, add glows/gradients, or re-type the name in a live font.

PALETTE
Indigo #1D1147 · Cream #FFF4DC · Marigold #FFB000 · Saffron #FF6A13 · Rani #E4147E · Chili #D62839 · Peacock #00A8A0 · Cilantro #3FA34D · Violet #7B5CFF (tiny doses)
Never set cream text on bare marigold or saffron (fails contrast) — use indigo text there.

Fonts (free, SIL Open Font License — install from Google Fonts):
Bowlby One (display) · DM Sans (body) · Caveat (handwritten accents)

Questions? Send the "Your pick" summary from the brand page back to your designer.
