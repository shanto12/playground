CONCEPT ASSETS — USAGE RIGHTS TRANSFER ON AGREEMENT
===================================================

Curry District · Brand Glow-Up — Direction B · Royal
Prepared 05 Oct 2026 as part of an independent design proposal.
This is NOT the official Curry District identity. The files are concept artwork for review only.
Usage rights (logo, patterns, icons, illustrations) transfer to the restaurant only on a signed
agreement with the designer. Please don't print, publish or hand these to a vendor before then.

WHAT'S INSIDE
logo/svg ........ every mark (stacked = primary, horizontal, text-only, tagline lockups, emblem, small emblem, seal, wax seal, favicon, app icon, avatar)
logo/svg/colourways  foil · ivory · emerald · mono-gold · mono-ivory · mono-ink
logo/png ........ transparent PNG renders in foil (for midnight) and ivory (for light grounds)
patterns/svg .... 8 seamless repeats, 27 colourways (midnight · emerald · ivory, plus ruby & peacock bonuses). Vector: scale freely.
icons/svg ....... 42 icons with gold lines for DARK grounds. icons/svg-on-ivory = antique-gold lines for LIGHT grounds.
icons/svg-mono .. single colour (currentColor). icons/sprite.svg = all symbols, themeable with CSS variables.
illustrations ... 12 dish illustrations: svg (master) + transparent png 800×800.

LOGO RULES (short version)
- Clear space: X = cap height of DISTRICT. Keep 2X clear on every side (emblem/seal: 1/4 of the mark's width).
- Minimum size: stacked 110 px / 30 mm wide · horizontal 160 px / 40 mm · emblem 64 px tall / 20 mm (25 mm for foil) · below 48 px use emblem-small.
- Midnight: foil. Ivory: ivory colourway. Emerald: emerald colourway. Ruby/plum/peacock: mono-ivory or foil.
- Don't recolour, stretch, rotate or add effects to the foil (it is already a gradient).

PALETTE
Midnight #160B26 · Plum #4B1D52 · Emerald #0F4D3F · Peacock #117C86 · Ruby #A3173F · Saffron-gold #E9A63A (light #F7D98A, dark #B7791F) · Ivory #FBF3E4 · Blush #F4C9BB
Bright gold lines/text are for dark grounds only. On ivory use antique gold #B7791F for large text and ornaments only.

Fonts (free, SIL Open Font License — install from Google Fonts):
Fraunces (display; 600/800 + italics) · Hanken Grotesk (body)

Questions? Send the "Your pick" summary from the brand page back to your designer.
